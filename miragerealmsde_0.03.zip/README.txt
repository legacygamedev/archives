Mirage Realms � Created by Liam, Jacob and Robin.

HISTORY:

Mirage Realms was originally a project worked on by Liam. I later joined the team as programmer before eventually being replaced by Jacob, a new face on the scene. Jacob quickly showed everyone he was the best programmer in all the Mirage-based communities and eventually revolutionised just about every system we had. This was his public release of the developer�s edition of Mirage Realms.

For anyone curious the game is still going strong, although it�s now built using the same graphics engine and website integration system seen in Crystalshire.

BUGS:

No idea.
