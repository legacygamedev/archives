Lucky you, the name of the sound file no longer matters!
But you still need to use .wav files only!
No other formats are supported!