Lucky you, the name of the music file no longer matters!
But you still need to use .mid music files only!
No other formats are supported!