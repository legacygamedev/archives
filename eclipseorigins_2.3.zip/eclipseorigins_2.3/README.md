# EclipseOrigins
Free 2D MMORPG Maker written in Visual Basic 6. Commits include Robin's base (EO 2.0) and all of JC Snider's modifications (up to EO 4.3) between March 2012 and early 2015.
