    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA



This is the source code for Version 2 of the Cerberus Engine... I specify the exact version of the code
because there have been and will be other versions available not covered under this release license.
Version 1 is a hybrid of miragesource code and Konfuze and will NOT be released.
Version 3 is still under production (as of 02/2008) and is most likely to stay closed source,
but you never know!

For details of the features contained in this engine I have included dated developement logs and all other
literature I could think of that might help you decipher what you can do with it.
The only thing I can tell you it HASN'T got is sound/music support, you'll have to add that yourself.

The source release is accompanied by the compiled versions of the code and all additional files
required to run the engine, notes on this are contained in the userguide text file.

If you decide to make your own engine with it, I can't stop you nor do I want to.
But I would ask that you make at least one reference to the miragesource community somewhere
in the engines documentation or credits as this is where the engine was born.

There is no official support for this version of the engine, what info there is is available at:

	- www.miragesource.com
	- www.key2heaven.net/ms

If you want to know more or have any questions or feedback, contact me on either
of these sites or via mail at ambientiger@ambientiger.com

And now... Have fun!

Peace, Tigzz