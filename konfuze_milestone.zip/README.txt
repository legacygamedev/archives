Konfuze Milestone � Created by Liam & Sean.

HISTORY:

This was it. This was /the/ engine to use back in the day. It had shit no one had ever seen before. Hell, back then there was actually a syndicate of Mirage users actually keeping the secret of scrolling maps private to those who could do it themselves. This had everything. Some amazing games were developed with this.

Although originally closed-source this thing offered one of the most developed scripting engines of its time. We loved it! This source was finally released during a mix-up between Liam (Coke) and Sean (GodSentDeath). Elysium was created and another chapter in Mirage history was closed.

BUGS:

Far too many to list. Just because it was good back the doesn�t mean it is any more.
