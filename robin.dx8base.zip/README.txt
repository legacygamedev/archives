DX8 Base � Created by Robin

HISTORY:

Just a simple test project for the DX8 class I was developing back in 2006/2007. Built on top of Emily�s original DX8 class using some of the techniques developed by Harold. This was the first time RMVX graphics were used in a Mirage Project and was actually a pre-cursor to Life Essence, the DX8 version of Wind�s Whisper and, eventually, Crystalshire.

BUGS:

None.
