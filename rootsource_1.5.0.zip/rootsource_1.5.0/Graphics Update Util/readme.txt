RS-BMP2PNG Documentation

Place executable in client root, where it can see the /gfx/ folder. It will complain if it cannot find it. Follow the instructions in the console, it should be fairly straight forward.