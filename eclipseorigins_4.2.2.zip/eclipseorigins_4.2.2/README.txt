Dungeons + Instances removed. All other features in tact, drm removed, source included.

(No other modifications made, should run exactly like EO 4.2.1 minus dungeons/instances)