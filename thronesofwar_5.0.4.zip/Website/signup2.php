<?php include 'header.inc'; include 'config.inc';
$dbh = mysql_connect($hostname, $username, $password) or die("Unable to connect to MySQL");
mysql_select_db("immortaluniverse") or die(mysql_error());
if ($_POST['action'] == 'submitted') {
$usernameerror = false;
$passworderror = false;
$chosenusername = $_POST['username'];
$result = mysql_query("SELECT * FROM characters WHERE `Name` = '$chosenusername'") or die(mysql_error());
$num_rows = mysql_num_rows($result);
if ($num_rows ) { echo "<font color='red'>* Error: This username is already registered.</font><br />"; $usernameerror = true;}
if (strlen($chosenusername) < 4) { echo "<font color='red'>* Error: Your username must be longer than three letters in length.</font><br />"; $usernameerror = true;}
if (strrpos($chosenusername, "/") != false) { echo "<font color='red'>* Error: Slashes are not allowed in your username.</font><br />"; $usernameerror = true;}
if (strrpos($chosenusername, trim("\ ")) != false) { echo "<font color='red'>* Error: Backslashes are not allowed in your username.</font><br />"; $usernameerror = true;}
if (strrpos($chosenusername, "*") != false) { echo "<font color='red'>* Error: Asterics are not allowed in your username.</font><br />"; $usernameerror = true;}
if (strrpos($chosenusername, "_") != false) { echo "<font color='red'>* Error: Underscores are not allowed in your username.</font><br />"; $usernameerror = true;}
if (strrpos($chosenusername, " ") != false) { echo "<font color='red'>* Error: Spaces are not allowed in your username.</font><br />"; $usernameerror = true;}
} ?>
<p style="font-family:verdana;font-size:80%;color:white">
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<p style="font-family:verdana;font-size:80%;color:white">
<?php if ($_POST['action'] == 'submitted' && $usernameerror == true) { echo "<font color='red'>* Username:</font>";} else { echo "Username:";} ?>
<input type="text" name="username" value="<?php echo $_POST['username']; ?>" />
<input type="hidden" name="action" value="submitted" />
<p style="font-family:verdana;font-size:80%;color:white">
<?php if ($_POST['action'] == 'submitted' && $passworderror == true) { echo "<font color='red'>* Password:</font>";} else { echo "Password:";} ?> 
<input type="password" name="password" />
<p style="font-family:verdana;font-size:80%;color:white">
<?php if ($_POST['action'] == 'submitted' && $passworderror == true) { echo "<font color='red'>* Re-type Password:</font>";} else { echo "Re-type Password:";} ?> 
<input type="password" name="repassword" />
<p style="font-family:verdana;font-size:80%;color:white">
<?php if ($_POST['action'] == 'submitted' && $emailerror == true) { echo "<font color='red'>* E-mail:</font>";} else { echo "E-mail:";} ?> 
<input type="text" name="email" value="<?php echo $_POST['email']; ?>" />
<p style="font-family:verdana;font-size:80%;color:white">
<?php if ($_POST['action'] == 'submitted' && $referrererror == true) { echo "<font color='red'>* Referrer:</font>";} else { echo "Referrer:";} ?> 
<?php if ($_POST['action'] == 'submitted') { echo '<input type="text" name="referrer" value="<?php echo $_POST[referrer]; ?>" />'; } else {
<input type="text" name="referrer" value="<?php echo $_GET[referrer]; ?>" />
<p /><img src="/images/skin<?php echo rand()%6; ?>.gif"><br /><input type="submit" name="submit" value="Sign Up." />
</form>
<?php
//$dbh = mysql_connect($hostname, $username, $password) or die("Unable to connect to MySQL");
//mysql_select_db("immortaluniverse") or die(mysql_error());
//$sqlquery = "INSERT INTO `accounts` ( `FKey` , `Login` , `Password` , `Suspended` , `Banned` , `HDModel` , `HDSerial` , `PriChar` , `Language` , `Referred` , `Referrals` , `AllowedInBeta` ) VALUES ('', 'Test', 'test', '0', '0', '' , '' , '0', '0', '0', '0', '0');";
//$results = mysql_query($sqlquery);
mysql_close($dbh);?>
<?php include 'bottom.inc'; ?>