<?php include 'header.inc'; include 'config.inc';
$dbh = mysql_connect($hostname, $username, $password) or die("Unable to connect to MySQL");
mysql_select_db("immortaluniverse") or die(mysql_error());
$result = mysql_query("SELECT * FROM settings") or die(mysql_error()); $row = mysql_fetch_array( $result );
echo "<marquee><p style='font-family:verdana;font-size:80%;color:aqua'>Message of the Day: " . $row['MOTD'] . "</p></marquee>";
?>
<p style="font-family:verdana;font-size:80%;color:red">You are currently not logged into the website. Please enter your username and password below and log in to gain access, or <a href="signup.php">create</a> an account.<hr /></p>
<p style="font-family:verdana;font-size:80%;color:white">
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<p style="font-family:verdana;font-size:80%;color:white">Username: <input type="text" name="username" value="<?php echo $_POST['username']; ?>" />
<p style="font-family:verdana;font-size:80%;color:white">Password: <input type="password" name="password" value="<?php echo $_POST['password']; ?>" />
<p /><img src="/images/skin<?php echo rand()%6; ?>.gif"><br /><input type="submit" name="submit" value="Log In." />
</form>

<p style="font-family:verdana;font-size:80%;color:white">
<?php
$result = mysql_query("SELECT * FROM settings") or die(mysql_error()); $row = mysql_fetch_array( $result );
$towusername = $_POST['username'];
$result = mysql_query("SELECT * FROM characters WHERE `Name` = '$towusername'")
or die(mysql_error());
if ( $row['Online'] == 1 ) {
echo "<font color=green>The server is online.</font><br />";
echo "Player(s) Online: ".$row['Players'];
echo "<br>Player"; if ($row['Players'] != "1") { echo "s"; } echo ": ".$row['OnlineList'];
} else {
echo "<font color=red>The server isn't online at the moment.</font>";
} 
// store the record of the "example" table into $row
$row = mysql_fetch_array( $result );
$spellarray = $row['Spells'];
$spellarray = explode("-", $spellarray);
//echo var_dump($spellarray);
if (trim($towusername) !== "") {
//if (mysql_num_rows($result)) !== "1" {
//echo 'Doesn't exist.';
//} else {
echo $towusername; echo "'s Spells:<br>";
$i = 0;
while ($i < count($spellarray)) {
//$spellnumber = $spellarray[$i];
if ($spellarray[$i] !== "0") {
$result = mysql_query("SELECT * FROM Spells WHERE `FKey` = '$spellarray[$i]'")
or die(mysql_error());

// store the record of the "example" table into $row
$row = mysql_fetch_array( $result );
echo $row['Name'];echo '<br>';
}
$i++;
}}
mysql_close($dbh);?>


</p>
<?php include 'bottom.inc'; ?>