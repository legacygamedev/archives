<?php include 'header.inc'; include 'config.inc';
if ($_POST['action'] == 'submitted') {
$usernameerror = false;
$passworderror = false;
$emailerror = false;
$referrererror = false;
$chosenusername = $_POST['username'];
$chosenpassword = $_POST['password'];
$chosenreferrer = $_POST['referrer'];
if ((strlen($chosenusername) < 4 or strlen($chosenusername) > 9)  && $usernameerror == false) { echo "<font color='red'>* Error: Your username must be at least four characters in length.</font><br />"; $usernameerror = true;}
if (strrpos($chosenusername, "/") != false && $usernameerror == false) { echo "<font color='red'>* Error: Slashes are not allowed in your username.</font><br />"; $usernameerror = true;}
if (strrpos($chosenusername, trim("\ ")) != false && $usernameerror == false) { echo "<font color='red'>* Error: Backslashes are not allowed in your username.</font><br />"; $usernameerror = true;}
if (strrpos($chosenusername, "*") != false && $usernameerror == false) { echo "<font color='red'>* Error: Asterics are not allowed in your username.</font><br />"; $usernameerror = true;}
if (strrpos($chosenusername, "_") != false && $usernameerror == false) { echo "<font color='red'>* Error: Underscores are not allowed in your username.</font><br />"; $usernameerror = true;}
if (strrpos($chosenusername, " ") != false && $usernameerror == false) { echo "<font color='red'>* Error: Spaces are not allowed in your username.</font><br />"; $usernameerror = true;}
$dbh = mysql_connect($hostname, $username, $password) or die("Unable to connect to MySQL");
mysql_select_db("immortaluniverse") or die(mysql_error());
$result = mysql_query("SELECT * FROM accounts WHERE `Login` = '$chosenusername'") or die(mysql_error());
$num_rows = mysql_num_rows($result);
if ($num_rows && $usernameerror == false) { echo "<font color='red'>* Error: This username is already registered.</font><br />"; $usernameerror = true; mysql_close($dbh);}

if ((strlen($_POST['password']) < 5 or strlen($_POST['password']) > 8) && $passworderror == false) { echo "<font color='red'>* Error: Your password must be at least five characters in length.</font><br />"; $passworderror = true;}
if (strrpos($_POST['password'], "/") != false && $passworderror == false) { echo "<font color='red'>* Error: Slashes are not allowed in your password.</font><br />"; $passworderror = true;}
if (strrpos($_POST['password'], trim("\ ")) != false && $passworderror == false) { echo "<font color='red'>* Error: Backslashes are not allowed in your password.</font><br />"; $passworderror = true;}
if (strrpos($_POST['password'], "*") != false && $passworderror == false) { echo "<font color='red'>* Error: Asterics are not allowed in your password.</font><br />"; $passworderror = true;}
if (strrpos($_POST['password'], "_") != false && $passworderror == false) { echo "<font color='red'>* Error: Underscores are not allowed in your password.</font><br />"; $passworderror = true;}
if (strrpos($_POST['password'], " ") != false && $passworderror == false) { echo "<font color='red'>* Error: Spaces are not allowed in your password.</font><br />"; $passworderror = true;}
if ($_POST['password'] !== $_POST['repassword']  && $passworderror == false)  { echo "<font color='red'>* Error: Your passwords did not match. Please try again.</font><br />"; $passworderror = true;}

if (((strlen($chosenreferrer) < 4 && trim($chosenreferrer) != "") or strlen($chosenreferrer) > 9)  && $referrererror == false) { echo "<font color='red'>* Error: Your referrer's name must be at least four characters in length.</font><br />"; $referrererror = true;}
if (strrpos($chosenreferrer, "/") != false && $referrererror == false) { echo "<font color='red'>* Error: Slashes are not allowed in your referrer's name.</font><br />"; $referrererror = true;}
if (strrpos($chosenreferrer, trim("\ ")) != false && $referrererror == false) { echo "<font color='red'>* Error: Backslashes are not allowed in your referrer's name.</font><br />"; $referrererror = true;}
if (strrpos($chosenreferrer, "*") != false && $referrererror == false) { echo "<font color='red'>* Error: Asterics are not allowed in your referrer's name.</font><br />"; $referrererror = true;}
if (strrpos($chosenreferrer, "_") != false && $referrererror == false) { echo "<font color='red'>* Error: Underscores are not allowed in your referrer's name.</font><br />"; $referrererror = true;}
if (strrpos($chosenreferrer, " ") != false && $referrererror == false) { echo "<font color='red'>* Error: Spaces are not allowed in your referrer's name.</font><br />"; $referrererror = true;}
$dbh = mysql_connect($hostname, $username, $password) or die("Unable to connect to MySQL");
mysql_select_db("immortaluniverse") or die(mysql_error());
$result = mysql_query("SELECT * FROM accounts WHERE `Login` = '$chosenreferrer'") or die(mysql_error());
$num_rows = mysql_num_rows($result);
if ($num_rows == 0 && $referrererror == false && trim($chosenreferrer) != "") { echo "<font color='red'>* Error: The account you put in as your referrer does not exist.</font><br />"; $referrererror = true; mysql_close($dbh);}
} 
if ($_POST['action'] == 'submitted' && $usernameerror == false && $passworderror == false && $referrererror == false) { 
$sqlquery = "INSERT INTO `accounts` ( `FKey` , `Login` , `Password` , `Suspended` , `Banned` , `HDModel` , `HDSerial` , `PriChar` , `Language` , `Referred` , `Referrals` , `AllowedInBeta` , `Referrer` ) VALUES ('', '$chosenusername', '$chosenpassword', '0', '0', '' , '' , '0', '0', '0', '0', '0', '$chosenreferrer');";
$results = mysql_query($sqlquery); mysql_close($dbh);

$message = "Thank you for signing up for Thrones of War, $chosenusername!

Your personal account for the Thrones of War website and game have been created! To log in, please proceed to the following address: http://www.thronesofwar.com/ and download the game!

Your personal login username and password are as follows. Please write down this information, and do not share it with others:
username: $chosenusername
password: $chosenpassword

Remember, you aren't stuck with this password! Your can change it at any time after you have logged in. If you have any problems, feel free to contact me at mi.amor@gmail.com.

Have fun!

-Kenko
Thrones of War Administrator (http://www.thronesofwar.com)"; 

mail($_POST['email'],"Welcome to Thrones of War", $message, "From:Kenko <mi.amor@gmail.com>");
?>
<p style="font-family:verdana;font-size:80%;color:white">Thank you for registering! Click <a href="/index.php">here</a> to go back to the main page.</p>
<?php
} else {
?>
<p style="font-family:verdana;font-size:80%;color:white">
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
<p style="font-family:verdana;font-size:80%;color:white">
<?php if ($_POST['action'] == 'submitted' && $usernameerror == true) { echo "<font color='red'>* Username:</font>";} else { echo "Username:";} ?>
<input type="text" name="username" maxlength="9" value="<?php echo $_POST['username']; ?>" />
<input type="hidden" name="action" value="submitted" />
<p style="font-family:verdana;font-size:80%;color:white">
<?php if ($_POST['action'] == 'submitted' && $passworderror == true) { echo "<font color='red'>* Password:</font>";} else { echo "Password:";} ?> 
<input type="password" maxlength="8" name="password" />
<p style="font-family:verdana;font-size:80%;color:white">
<?php if ($_POST['action'] == 'submitted' && $passworderror == true) { echo "<font color='red'>* Re-type Password:</font>";} else { echo "Re-type Password:";} ?> 
<input type="password" maxlength="8" name="repassword" />
<p style="font-family:verdana;font-size:80%;color:white">
<?php if ($_POST['action'] == 'submitted' && $emailerror == true) { echo "<font color='red'>* E-mail:</font>";} else { echo "E-mail:";} ?> 
<input type="text" name="email" value="<?php echo $_POST['email']; ?>" />
<p style="font-family:verdana;font-size:80%;color:white">
<?php if ($_POST['action'] == 'submitted' && $referrererror == true) { echo "<font color='red'>* Referrer:</font>";} else { echo "Referrer:";} ?> 

<?php if ($_POST['action'] == 'submitted') 
{ echo '<input type="text" name="referrer" maxlength="9" value="' . $_POST[referrer] . '">'; } else {
echo '<input type="text" name="referrer" maxlength="9" value="' . $_GET[referrer] . '">'; } 
?>
<p /><img src="/images/skin<?php echo rand()%6; ?>.gif"><br /><input type="submit" name="submit" value="Sign Up." />
</form>
<?php
} ?>
<?php include 'bottom.inc'; ?>