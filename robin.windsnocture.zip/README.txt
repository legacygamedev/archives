Robin's Amazing Package � Created by Robin.

HISTORY:

A copy of Wind�s Nocturne with a load of random shit added. This was on sale late 2010 for around �60. Contained my long sought after method of DD7 alpha blending which I developed back in 2004 whilst working on Naruto Realm. Also contains Jacob�s quest system amongst other things. Also a /horribly/ implementation of autotiles. Although I learnt a lot from the project and later used the experiences to create Crystalshire, the spiritual successor.

BUGS:

Far too many to list.
