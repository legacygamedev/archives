Title: Alphablending AND Animated Gifs in DirectX!
Description: A while ago I posted some source code which allowed the loading of animated gifs into directx. A while later I wrote some code which allowed alpha blending in directx. Today, I rewrote the alpha blending code to use getlockedarray instead of pixel, which quite significantly sped the alpha blending up, and combined these 2 codes into 1. I average around 26fps without alphablending, and 24-25 with, which I think is a pretty good number, given that this is 100% vb :).
If anyone find any problems or has any ideas, feel free to email me.
Jim
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=40642&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
