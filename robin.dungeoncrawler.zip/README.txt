Dungeon Crawler � Created by Robin

HISTORY:

Was a small side-project I built when developing my DX8 class back in 2006-2007. Originally intended as a small 4 player game to play with my real life friends. As far as I remember the multiple works and you can walk around spawning trees. I was originally going to have someone set as the GM who would have the power to teleport around the other three players spawning fights, treasure etc. You know, like the old D&D games. This is actually a very early version and I did end up developing a fully working system which we used to play. The source code got lost during a HDD transition and I�ve never found it since.

BUGS:

None. Unfinished project.
