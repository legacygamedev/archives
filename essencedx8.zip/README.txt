Essence DX8 � Created by Robin

HISTORY:

Although it sported the Essence brand name this was actually built on a copy of MSE1 as far as I remember. This was the first huge improvement to the DX8 code developed in �DX8 Base�, �DX8 Engine� and �Life Essence�. It also had some pretty solid graphical tutorials developed to aid people in the transition between making DD7 GUIs to DX8 ones. This also contained the first ever fully-working dynamic maps system. Again, pretty solid stuff for 2007.

BUGS:

No idea.
