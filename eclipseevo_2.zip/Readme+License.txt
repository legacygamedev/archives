/\/\/\/\/\/\/\/\/\
ECLIPSE EVO SOURCE
\/\/\/\/\/\/\/\/\/

LICENSE:
-------
Eclipse Evolution is copyright 2007 by Marsh/Touch of Death Productions.

By downloading this source code, you agree
not to sell or redistribute this code in
exchange for money or other goods. This source
code is free of charge and will remain that way.
Also, you agree not to market, advertise, or
otherwise distribute Eclipse Evolution Source or
any deriatives as your own work, without the express
consent of Marsh and Touch of Death Productions. You
may freely distribute any program compiled from EE
source - i.e. you may distribute any game created with it,
however we reserve the right to revoke this statement
at any time.

Touch of Death Productions takes no responsibility for any legal matters involving
graphics, music, images, and other resources used in games created with
Eclipse Evolution, including the default resources provided. The person or
persons using the Eclipse Evolution engine are responsible for providing
their own graphics, music, images and other resources.

Any questions can be answered on the forum:
www.freemmorpgmaker.com/smf


README:
------
Okay! With the legalese out of the way, welcome
to EE source. Couple important things:

-Make sure you go into the server and client and
change the SEC_CODEs. Otherwise, anyone with the
soruce will have them.

-If you're an experienced programmer you may want
to add some sort of packet encryption. If you decide
to, IncomingData, SendData, and SendDataToAll are good
places to start.

-All the main structures for EE are declared in modTypes.
If you're new, that's a good place to start reading.

-You DO need a copy of VB6 to use this. VB 2005 will NOT
work.

-The security codes are different in the compiled version
and the source, so don't get any ideas ;]

