Pok�mon Origins � Created by Robin.

HISTORY:

A 1-hour job to see how easy a turn-based combat system could be implemented. Was instantly ditched as I was considering joining Emily�s Pok�mon project which had just about all the original Gameboy game systems implemented � even a fully animated replica of the Pok�mon Fire Red intro sequence!

BUGS:

Far too many to list.
