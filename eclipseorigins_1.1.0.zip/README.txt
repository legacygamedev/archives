Eclipse Origins v1.1.0 � Created by Robin

HISTORY:

One of the original releases of Origins. This particular version was from late 2009 and was released before the huge amount of core engine re-working I did during 2010. Simply here for nostalgia.

BUGS:

Any bugs fixed in v1.1.1 to v2. Don�t use this source you tit.
