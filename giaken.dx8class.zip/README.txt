Harold�s DX8 Class � Created by Harold.

HISTORY:

Created by a long-time friend of mine Harold (GIAKEN) was one of the three musketeers who were pioneering the general usage of DX8 amongst the forums. (Emily, Harold and I.) This particular version is a modification of Emily�s original class.

BUGS:

Texture corruption.
