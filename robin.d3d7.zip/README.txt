D3D7 Engine - Created by Robin

HISTORY:

Small test project I created a good few years ago. I believe it was supposed to be a D3D7/DD7 hybrid with DirectInput and DirectSound. I seem to remember getting the blending working but never texture rendering. Take it for what you will.

BUGS:

Doesn�t work?
