lolShooter � Created by Robin.

HISTORY:

Early attempt at a 1-hour project. Ended up taking a longer time but I had fun developing it. Based on the final version of my DX8 class. I later ported this to Java.

BUGS:

No idea.
