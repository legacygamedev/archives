Essence DX7 � Created by Robin

HISTORY:

This was my first stand-alone engine which was released on its own site. Liam (The creator of Konfuze) donated his �pwnz.co.uk� domain to me and I used it to give you all Essence! This was one of the most revolutionary engines of its time. Keep in mind this was over 4 years ago in 2007. There�s really too much to list. I�ll just say that this was where I finally went public with a lot of ideas which I�d been using in my personal games that year. Hell, the source code itself is actually a modification of Wind�s Whisper.

BUGS:

No idea.
