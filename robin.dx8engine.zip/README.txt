DX8 Engine � Created by Robin

HISTORY:

Evolved version of the �DX8 Base�. This included the first dynamic texture loading routines and memory management routines which would later become a huge part of EO and Crystalshire.

BUGS:

None.
